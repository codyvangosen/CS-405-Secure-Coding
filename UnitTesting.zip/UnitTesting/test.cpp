#include "pch.h"  // Include precompiled header file
#include "gtest/gtest.h"  // Include Google Test framework
#include <vector>  // Include vector for collection testing
#include <stdexcept>  // Include stdexcept for exception handling

// Define the test environment class
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}  // Destructor

    void SetUp() override {
        srand(time(nullptr));  // Initialize random seed based on current time
    }

    void TearDown() override {}  // No specific tear-down required
};

// Define test fixture class for collection testing
class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;  // Smart pointer to a vector of integers

    void SetUp() override {
        collection.reset(new std::vector<int>);  // Initialize a new empty vector
    }

    void TearDown() override {
        collection->clear();  // Clear all elements in the collection
        collection.reset(nullptr);  // Reset the smart pointer
    }

    void add_entries(int count) {  // Helper function to add random values to the collection
        assert(count > 0);  // Ensure count is positive
        for (auto i = 0; i < count; ++i)  // Loop through count times
            collection->push_back(rand() % 100);  // Insert a random number between 0-99
    }
};

// Test case to verify the collection pointer is initialized
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);  // Verify the collection is initialized
    ASSERT_NE(collection.get(), nullptr);  // Ensure collection pointer is not null
}

// Test case to verify that the collection is empty upon initialization
TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());  // Collection should be empty initially
    ASSERT_EQ(collection->size(), 0);  // Collection size should be 0
}

// Test case to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector) {
    ASSERT_TRUE(collection->empty());  // Ensure collection starts empty
    ASSERT_EQ(collection->size(), 0);  // Ensure initial size is 0

    add_entries(1);  // Add one entry to the collection

    ASSERT_FALSE(collection->empty());  // Collection should no longer be empty
    ASSERT_EQ(collection->size(), 1);  // Collection size should be exactly 1
}

// Test case to verify adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);  // Add five entries to the collection
    ASSERT_EQ(collection->size(), 5);  // Collection size should be exactly 5
}

// Test case to verify max_size() is greater than or equal to the collection size
TEST_F(CollectionTest, MaxSizeIsGreaterOrEqualSize) {
    std::vector<int> temp;  // Create a temporary vector
    ASSERT_GE(temp.max_size(), temp.size());  // Ensure max_size is at least the size

    add_entries(1);  // Add one entry
    ASSERT_GE(collection->max_size(), collection->size());  // Check max_size constraint

    add_entries(4);  // Add four more entries
    ASSERT_GE(collection->max_size(), collection->size());  // Ensure max_size holds

    add_entries(5);  // Add five more entries
    ASSERT_GE(collection->max_size(), collection->size());  // Verify max_size
}

// Test case to verify capacity() is greater than or equal to collection size
TEST_F(CollectionTest, CapacityIsGreaterOrEqualSize) {
    std::vector<int> temp;  // Create a temporary vector
    ASSERT_GE(temp.capacity(), temp.size());  // Ensure capacity is at least size

    add_entries(1);  // Add one entry
    ASSERT_GE(collection->capacity(), collection->size());  // Verify capacity constraint

    add_entries(4);  // Add four more entries
    ASSERT_GE(collection->capacity(), collection->size());  // Check capacity is at least size
}

// Test case to verify resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection) {
    collection->resize(10);  // Resize collection to 10
    ASSERT_EQ(collection->size(), 10);  // Verify new size is 10
}

// Test case to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection) {
    collection->resize(10);  // Expand collection to size 10
    collection->resize(5);  // Shrink collection to size 5
    ASSERT_EQ(collection->size(), 5);  // Verify new size is 5
}

// Test case to verify resizing collection to zero
TEST_F(CollectionTest, ResizingDecreasesCollectionToZero) {
    collection->resize(10);  // Expand collection to size 10
    collection->resize(0);  // Shrink collection to zero
    ASSERT_EQ(collection->size(), 0);  // Verify collection is empty
}

// Test case to verify clear() erases all elements
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(5);  // Add five entries
    collection->clear();  // Clear collection
    ASSERT_EQ(collection->size(), 0);  // Verify collection is empty
}

// Test case to verify erase(begin, end) removes all elements
TEST_F(CollectionTest, EraseRemovesCollectionRange) {
    add_entries(5);  // Add five entries
    collection->erase(collection->begin(), collection->end());  // Erase all elements
    ASSERT_EQ(collection->size(), 0);  // Verify collection is empty
}

// Test case to verify reserve() increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {
    size_t prev_capacity = collection->capacity();  // Store previous capacity
    collection->reserve(prev_capacity + 10);  // Increase capacity by 10
    ASSERT_GT(collection->capacity(), prev_capacity);  // Ensure capacity increased
    ASSERT_EQ(collection->size(), 0);  // Ensure size remains unchanged
}

// Negative test case to verify out-of-range exception is thrown
TEST_F(CollectionTest, OutOfRangeThrowsException) {
    ASSERT_THROW(collection->at(0), std::out_of_range);  // Accessing empty collection should throw exception
}

// Custom positive test case
TEST_F(CollectionTest, CustomPositiveTest) {
    add_entries(3);  // Add three entries
    ASSERT_EQ(collection->size(), 3);  // Verify size is 3
    collection->pop_back();  // Remove last entry
    ASSERT_EQ(collection->size(), 2);  // Verify size is reduced to 2
}

// Custom negative test case
TEST_F(CollectionTest, CustomNegativeTest) {
    collection->push_back(5);  // Add one entry
    ASSERT_THROW(collection->at(1), std::out_of_range);  // Access out-of-bounds index should throw exception
}
