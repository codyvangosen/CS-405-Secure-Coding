// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstring> // For safer string manipulation
#include <limits>  // For clearing input buffer

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: Prevent buffer overflow while keeping the account_number constant and in the same position.

    // Constant variable representing the account number
    const std::string account_number = "CharlieBrown42";

    // User input buffer with a fixed size of 20 characters (19 usable + null terminator)
    char user_input[20];

    // Inform the user of the input size limit to help prevent overflow
    std::cout << "Enter a value (max 19 characters): ";

    // Using std::cin.get() to read input safely into the buffer without exceeding its size
    std::cin.get(user_input, sizeof(user_input)); // Read up to 19 characters plus null terminator

    // Check if input exceeds the allowed size of the buffer
    if (std::cin.gcount() == sizeof(user_input) - 1 && std::cin.peek() != '\n') {
        std::cout << "\nError: Input exceeded the maximum allowed length (19 characters)!" << std::endl;

        // Clear the remaining input buffer to prevent undefined behavior in subsequent operations
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    // Ensure the user input is null-terminated to prevent overflow issues during output
    user_input[sizeof(user_input) - 1] = '\0';

    // Display the user-provided input and the account number
    std::cout << "\nYou entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Detailed Explanation of Changes:
// 1. Used std::cin.get() to safely read input into the buffer, limiting it to its size.
// 2. Added a check to detect when the input exceeds the buffer size (19 characters + null terminator).
// 3. Implemented error notification to inform users when their input is too long.
// 4. Utilized std::cin.ignore() to clear excess input from the stream, ensuring no leftover data interferes with subsequent operations.
// 5. Enforced null-termination of the user input buffer to eliminate potential memory issues when displaying the string.
// 6. Preserved the account_number constant and ensured it remains in its original position relative to the user input buffer.
// 7. Followed industry best practices by including inline comments for all changes, adhering to coding standards, and ensuring robust error handling.
