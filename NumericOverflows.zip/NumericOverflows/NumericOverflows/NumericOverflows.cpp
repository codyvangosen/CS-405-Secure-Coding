// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // std::typeid

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">Reference to store the final result</param>
/// <returns>Boolean indicating success (true) or overflow (false)</returns>
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& result)
{
    result = start; // Initialize result with the starting value

    for (unsigned long int i = 0; i < steps; ++i) // Loop through the number of steps
    {
        // Check if adding the increment would cause overflow
        if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
        {
            return false; // Overflow detected, return false
        }
        result += increment; // Perform the addition if safe
    }

    return true; // Indicate success if no overflow occurred
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">Reference to store the final result</param>
/// <returns>Boolean indicating success (true) or underflow (false)</returns>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& result)
{
    result = start; // Initialize result with the starting value

    for (unsigned long int i = 0; i < steps; ++i) // Loop through the number of steps
    {
        // Check if subtracting the decrement would cause underflow
        if (decrement > 0 && result < std::numeric_limits<T>::min() + decrement)
        {
            return false; // Underflow detected, return false
        }
        result -= decrement; // Perform the subtraction if safe
    }

    return true; // Indicate success if no underflow occurred
}

/// <summary>
/// Test function for detecting numeric overflow
/// </summary>
template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps; // Increment calculated to avoid immediate overflow
    const T start = 0; // Starting point for the addition

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result; // Variable to store the result of the addition

    // Test adding numbers without overflow
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    if (add_numbers<T>(start, increment, steps, result))
    {
        std::cout << +result << std::endl; // Print the result if no overflow occurred
    }
    else
    {
        std::cout << "Overflow occurred!" << std::endl; // Indicate overflow occurred
    }

    // Test adding numbers with overflow
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    if (add_numbers<T>(start, increment, steps + 1, result))
    {
        std::cout << +result << std::endl; // Print the result if no overflow occurred
    }
    else
    {
        std::cout << "Overflow occurred with extra step!" << std::endl; // Indicate overflow occurred
    }
}

/// <summary>
/// Test function for detecting numeric underflow
/// </summary>
template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps; // Decrement calculated to avoid immediate underflow
    const T start = std::numeric_limits<T>::max(); // Starting point for the subtraction

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result; // Variable to store the result of the subtraction

    // Test subtracting numbers without underflow
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    if (subtract_numbers<T>(start, decrement, steps, result))
    {
        std::cout << +result << std::endl; // Print the result if no underflow occurred
    }
    else
    {
        std::cout << "Underflow occurred!" << std::endl; // Indicate underflow occurred
    }

    // Test subtracting numbers with underflow
    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    if (subtract_numbers<T>(start, decrement, steps + 1, result))
    {
        std::cout << +result << std::endl; // Print the result if no underflow occurred
    }
    else
    {
        std::cout << "Underflow occurred with extra step!" << std::endl; // Indicate underflow occurred
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primitive types for overflow
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primitive types for underflow
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

int main()
{
    const std::string star_line = std::string(50, '*'); // Divider line for output readability

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line); // Run overflow tests
    do_underflow_tests(star_line); // Run underflow tests

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0; // Indicate successful program execution
}