// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    // Override what() method to return a custom error message
    const char* what() const noexcept override {
        return "Custom Exception: An error occurred in custom application logic.";
    }
};

// Function that simulates additional application logic
bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard runtime exception to simulate an error
    throw std::runtime_error("Standard Exception: Error in do_even_more_custom_application_logic");

    return true; // This line will never be reached due to the exception
}

// Function that wraps custom application logic in exception handling
void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        // Attempting to execute additional logic that may throw an exception
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catching standard exceptions and displaying error messages
        std::cerr << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throwing a custom exception to demonstrate exception handling in main
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl; // This line will never be reached
}

// Function that performs division and handles division by zero
float divide(float num, float den) {
    if (den == 0) {
        // Throwing a standard exception when denominator is zero
        throw std::overflow_error("Divide by zero exception");
    }
    return (num / den); // Returning the result of division
}

// Function that attempts to divide numbers and handles exceptions
void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        // Attempting to divide numbers and storing the result
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::overflow_error& e) {
        // Catching division by zero exception and displaying an error message
        std::cerr << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

// Main function that wraps all function calls in exception handlers
int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        // Calling function that performs division
        do_division();

        // Calling function that executes custom logic
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        // Catching custom exception explicitly
        std::cerr << "Custom exception caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        // Catching all standard exceptions
        std::cerr << "Standard exception caught in main: " << e.what() << std::endl;
    }
    catch (...) {
        // Catching any other unhandled exceptions
        std::cerr << "Unknown exception caught in main." << std::endl;
    }

    return 0; // Returning success code
}
