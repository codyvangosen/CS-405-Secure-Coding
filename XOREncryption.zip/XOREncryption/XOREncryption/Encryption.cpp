// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// Encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption / decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get lengths of key and source
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Ensure key and source are not empty
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Loop through the source string character by character
    for (size_t i = 0; i < source_length; ++i)
    {
        // TODO: Implement XOR encryption
        // Each character in the output is computed using XOR operation with the key
        // The key index is determined using modulo operation to loop over the key
        output[i] = source[i] ^ key[i % key_length];
    }

    // Ensure the output length matches the source length
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Reads the content of a file and returns it as a string
/// </summary>
/// <param name="filename">Name of the file to read</param>
/// <returns>File contents as a string</returns>
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    std::ostringstream buffer;

    // Check if file opened successfully
    if (file)
    {
        buffer << file.rdbuf(); // Read file content into buffer
    }
    else
    {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
    }

    return buffer.str(); // Convert buffer stream to string
}

/// <summary>
/// Extracts the student name from the first line of the input string
/// </summary>
/// <param name="string_data">Input file content as a string</param>
/// <returns>Extracted student name</returns>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline character
    size_t pos = string_data.find('\n');

    // Check if a newline character was found
    if (pos != std::string::npos)
    {
        // Extract the substring before the newline as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

/// <summary>
/// Saves a given string to a specified file in the required format
/// </summary>
/// <param name="filename">Name of the file to save to</param>
/// <param name="student_name">Student name extracted from the file</param>
/// <param name="key">Key used for encryption</param>
/// <param name="data">Data to save in the file</param>
#include <ctime>  // Ensure time functions are included

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);

    // Check if file opened successfully
    if (file)
    {
        // Get current time for timestamp (Safe alternative using localtime_s)
        std::time_t now = std::time(nullptr);
        std::tm local_time;
        localtime_s(&local_time, &now); // Safe alternative to localtime()

        char timestamp[11]; // Format: YYYY-MM-DD
        std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d", &local_time);

        // Write data in the required format
        file << student_name << "\n";  // Line 1: Student name
        file << timestamp << "\n";      // Line 2: Timestamp
        file << key << "\n";            // Line 3: Encryption key
        file << data;                    // Line 4+: Encrypted/Decrypted content
    }
    else
    {
        std::cerr << "Error: Unable to write to file " << filename << std::endl;
    }
}


int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Input file format:
    // Line 1: <student's name>
    // Line 2: <Lorem Ipsum Generator website used> e.g., https://pirateipsum.me/
    // Lines 3+: <Lorem Ipsum text>

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key = "password"; // Encryption key

    // Read the content of the input file
    const std::string source_string = read_file(file_name);

    // Extract the student name from the file content
    const std::string student_name = get_student_name(source_string);

    // Encrypt sourceString using the key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save encrypted string to a file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt the encrypted string using the same key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save decrypted string to a file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    // Print process summary
    std::cout << "Read File: " << file_name << " - Encrypted To: "
        << encrypted_file_name << " - Decrypted To: "
        << decrypted_file_name << std::endl;

    // Students submit:
    // - Input file
    // - Encrypted file
    // - Decrypted file
    // - Source code
    // - Encryption key used
}
